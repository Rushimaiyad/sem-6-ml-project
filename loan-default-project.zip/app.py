
from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

model, scaler = pickle.load(open("model.pkl", "rb"))

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    income = float(request.form["income"])
    loan_amount = float(request.form["loan_amount"])
    credit_score = float(request.form["credit_score"])

    features = np.array([[income, loan_amount, credit_score]])
    features_scaled = scaler.transform(features)

    prediction = model.predict(features_scaled)[0]
    probability = model.predict_proba(features_scaled)[0][1]

    result = "Loan Default" if prediction == 1 else "No Default"

    return render_template("index.html",
                           prediction_text=result,
                           probability=round(probability*100,2))

if __name__ == "__main__":
    app.run(debug=True)
